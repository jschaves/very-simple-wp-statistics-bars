=== Very Simple WordPress Statistics Bars ===
Contributors: jchaves
Version:	1.2
Tags: statistics, pop-up
Stable tag: trunk
Requires at least: 4.4
Tested up to: 5.2
License: GPLv2 or later
Donate link: https://www.paypal.me/jschaves
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Very Simple WordPress Statistics 

== Description ==

Very Simple WordPress Statistics is a plugin to create customized statistics easily by means of a simple form.

This is how it works:


== Installation ==

Installation for General Use

* Upload the Very Simple WordPress Statistics plugin to your blog, activate it, then go to menu Settings and then select VSWP Statistics.
* In a post or page use the shortcode `[vswpstatistics ID=xxxxxxxxxxx title=xxxxxxxxxxxx]` to create a statistics link.

== Screenshots ==

1. screenshot-1.jpg
2. screenshot-2.jpg

== Changelog ==
