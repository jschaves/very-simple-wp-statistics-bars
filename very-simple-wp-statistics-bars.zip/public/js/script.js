"use strict";

(function($) {
	jQuery(document).ready(function() {

	});	
})(jQuery);